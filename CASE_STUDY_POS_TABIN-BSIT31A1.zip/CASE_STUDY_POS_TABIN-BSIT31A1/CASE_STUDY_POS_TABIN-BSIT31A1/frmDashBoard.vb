﻿Imports System.Data.OleDb

Module Globals
    Public UserRole As String = ""
    Public Username As String = ""


End Module

Public Class frmDashBoard

    Private _userName As String
    Private _userRole As String

    Public Sub New(userName As String, userRole As String)
        InitializeComponent()
        _userName = userName
        _userRole = userRole
    End Sub

    Private Sub DashboardForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Update the labels based on the username and user role
        UpdateUserLabels()
    End Sub

    Private Sub UpdateUserLabels()
        lblusername.Text = "" & _userName
        lblrole.Text = "" & _userRole
    End Sub

    'Menu Strip
    Private Sub btnManage_Click(sender As Object, e As EventArgs) Handles btnManage.Click
        ContextMenuStrip1.Show(btnManage, 0, btnManage.Height)
    End Sub

    'To show frmProducts
    Private Sub ToolStripMenuItemOpenProducts_Click(sender As Object, e As EventArgs) Handles ProductsToolStripMenuItem.Click
        Dim productsUserControl As New frmProducts()
        UpdateFormLabel("PRODUCT")
        Panel1.Controls.Clear()
        Panel1.Controls.Add(productsUserControl)
        productsUserControl.Dock = DockStyle.Fill
        productsUserControl.Show()
    End Sub

    'To show frmUsers
    Private Sub UsersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UsersToolStripMenuItem.Click
        Dim usersUserControl As New frmUsers()
        UpdateFormLabel("USERS")
        Panel1.Controls.Clear()
        Panel1.Controls.Add(usersUserControl)
        usersUserControl.Dock = DockStyle.Fill
        usersUserControl.Show()
    End Sub

    Private Sub PaymentToolStripMenuItem_Click(Sender As Object, e As EventArgs) Handles PaymentModeToolStripMenuItem.Click
        Dim PaymentUserControl As New frmPayment
        UpdateFormLabel("PAYMENT")
        Panel1.Controls.Clear()
        Panel1.Controls.Add(PaymentUserControl)
        PaymentUserControl.Dock = DockStyle.Fill
        PaymentUserControl.Show()
    End Sub

    Private Sub CategoriesToolStripMenuItem1_Click(Sender As Object, e As EventArgs) Handles CategoriesToolStripMenuItem1.Click
        Dim CategoryUserControl As New frmCategories
        UpdateFormLabel("CATEGORIES")
        Panel1.Controls.Clear()
        Panel1.Controls.Add(CategoryUserControl)
        CategoryUserControl.Dock = DockStyle.Fill
        CategoryUserControl.Show()
    End Sub
    Private Sub btnTransaction_Click(sender As Object, e As EventArgs) Handles btnTransaction.Click
        ContextMenuStrip2.Show(btnTransaction, 0, btnTransaction.Height)
    End Sub

    ' To show POS Update
    Private Sub POSToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles POSToolStripMenuItem.Click
        Dim posUpdateForm As New frmPOS()
        UpdateFormLabel("POS UPDATE")

        ' Show the form as a dialog
        If posUpdateForm.ShowDialog() = DialogResult.OK Then
            ' Handle any actions after the dialog is closed with OK button
        End If
    End Sub



    Private Sub btnReports_Click(sender As Object, e As EventArgs) Handles btnReports.Click
        ContextMenuStrip3.Show(btnReports, 0, btnReports.Height)
    End Sub

    'To show Sales Report
    Private Sub SalesReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ReportsToolStripMenuItem.Click
        Dim salesReportUserControl As New frmSalesReport()
        UpdateFormLabel("SALES REPORT")
        Panel1.Controls.Clear()
        Panel1.Controls.Add(salesReportUserControl)
        salesReportUserControl.Dock = DockStyle.Fill
        salesReportUserControl.Show()
    End Sub



    'To show Sales Report Details
    Private Sub SalesReportDetailsToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Dim salesReportDetailsUserControl As New frmSalesReportDetails()
        UpdateFormLabel("SALES REPORT DETAILS")
        Panel1.Controls.Clear()
        Panel1.Controls.Add(salesReportDetailsUserControl)
        salesReportDetailsUserControl.Dock = DockStyle.Fill
        salesReportDetailsUserControl.Show()
    End Sub

    'To show Activity Logs
    Private Sub ActivityLogsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ActivityLogsToolStripMenuItem.Click
        Dim ActivityLogsUserControl As New frmActivityLogs()
        UpdateFormLabel("ACTIVITY LOGS")
        Panel1.Controls.Clear()
        Panel1.Controls.Add(ActivityLogsUserControl)
        ActivityLogsUserControl.Dock = DockStyle.Fill
        ActivityLogsUserControl.Show()
    End Sub

    Private Sub UpdateFormLabel(formName As String)
        lblform.Text = formName
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        If MsgBox("You sure you wanna exit?", vbQuestion + vbYesNo) = vbYes Then
            Dim loginForm As frmLogin = New frmLogin()
            loginForm.RecordLogout(frmLogin.LoggedInUserName)

            MsgBox("Thanks for using Point of Sales System....")
            Me.Close()
            frmLogin.Close()
        End If
    End Sub



End Class
