﻿Imports System.Data.OleDb
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Button

Public Class frmChangePassword

    Dim cn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\tabin\Desktop\CASE_STUDY_POS_TABIN-BSIT31A1\CASE_STUDY_POS_TABIN-BSIT31A1\bin\x64\Debug\Database1.accdb") ' Replace with your actual connection string

    Private Sub frmChangePassword_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        InitializeTextBoxes()
        StyleButton(btnCreate)
        StyleButton(btnClose)
    End Sub

    Private Sub InitializeTextBoxes()
        Dim placeholders() As String = {"Username", "New Password", "Confirm New Password"}
        Dim textBoxes() As TextBox = {txtUsername, txtNewPassword, txtConfirmNewPassword}

        For i As Integer = 0 To placeholders.Length - 1
            Dim placeholder = placeholders(i)
            Dim textBox = textBoxes(i)

            SetPlaceholder(textBox, placeholder)
            AddHandler textBox.MouseEnter, Sub(sender, e) SetMouseEnter(sender, placeholder)
            AddHandler textBox.MouseLeave, Sub(sender, e) SetMouseLeave(sender, placeholder)
            AddHandler textBox.KeyPress, Sub(sender, e) PreventEditing(sender, placeholder, e)
        Next
    End Sub


    Private Sub SetMouseEnter(textBox As TextBox, placeholder As String)
        If textBox.Text = placeholder Then
            textBox.Text = ""
            textBox.ForeColor = Color.White
        End If
    End Sub

    Private Sub SetMouseLeave(textBox As TextBox, placeholder As String)
        If textBox.Text = "" Then
            SetPlaceholder(textBox, placeholder)
        End If
    End Sub

    Private Sub SetPlaceholder(textBox As TextBox, placeholder As String)
        textBox.Text = placeholder
        textBox.ForeColor = Color.Gray
    End Sub

    Private Sub PreventEditing(textBox As TextBox, placeholder As String, e As KeyPressEventArgs)
        If textBox.Text = placeholder Then
            e.Handled = True
        End If
    End Sub
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            txtNewPassword.PasswordChar = ControlChars.NullChar
            txtConfirmNewPassword.PasswordChar = ControlChars.NullChar
        Else
            txtNewPassword.PasswordChar = "●"
            txtConfirmNewPassword.PasswordChar = "●"
        End If
    End Sub

    Private Sub txtNewPassword_TextChanged(sender As Object, e As EventArgs) Handles txtNewPassword.TextChanged
        ' Set PasswordChar to "●" when typing the password
        If txtNewPassword.Text = "New Password" Then
            txtNewPassword.PasswordChar = ControlChars.NullChar
        Else
            txtNewPassword.PasswordChar = "●"
        End If
    End Sub

    Private Sub txtConfirmNewPassword_TextChanged(sender As Object, e As EventArgs) Handles txtConfirmNewPassword.TextChanged
        ' Set PasswordChar to "●" when typing the password
        If txtConfirmNewPassword.Text = "Confirm New Password" Then
            txtConfirmNewPassword.PasswordChar = ControlChars.NullChar
        Else
            txtConfirmNewPassword.PasswordChar = "●"
        End If
    End Sub

    Private Sub StyleButton(button As Button)
        button.FlatStyle = FlatStyle.Flat
        button.FlatAppearance.BorderSize = 0
        button.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255)
        button.BackColor = Color.FromArgb(127, 90, 240)
        ''button.FlatAppearance.MouseOverBackColor = Color.FromArgb(22, 22, 26)
        button.FlatAppearance.MouseDownBackColor = Color.FromArgb(114, 117, 126)

        Dim cornerRadius As Integer = 25
        Dim buttonPath As New Drawing2D.GraphicsPath()
        buttonPath.AddArc(0, 0, cornerRadius * 2, cornerRadius * 2, 180, 90)
        buttonPath.AddArc(button.Width - cornerRadius * 2, 0, cornerRadius * 2, cornerRadius * 2, 270, 90)
        buttonPath.AddArc(button.Width - cornerRadius * 2, button.Height - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 0, 90)
        buttonPath.AddArc(0, button.Height - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 90, 90)
        button.Region = New Drawing.Region(buttonPath)
    End Sub

    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        If ValidateForm() Then
            ChangePassword(txtUsername.Text, txtNewPassword.Text)
        End If
    End Sub


    Private Sub ChangePassword(username As String, newPassword As String)
        ' Use a using statement to ensure proper disposal of the connection
        Using cn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\tabin\Desktop\CASE_STUDY_POS_TABIN-BSIT31A1\CASE_STUDY_POS_TABIN-BSIT31A1\bin\x64\Debug\Database1.accdb") ' Replace with your actual connection string
            Try
                cn.Open()

                ' Update the password in the database
                Dim sql As String = "UPDATE tblUsers SET [Password] = @NewPassword WHERE [Username] = @Username"
                Using cmd As New OleDbCommand(sql, cn)
                    cmd.Parameters.AddWithValue("@NewPassword", newPassword)
                    cmd.Parameters.AddWithValue("@Username", username)
                    cmd.ExecuteNonQuery()
                End Using

                MsgBox("Password changed successfully", MsgBoxStyle.Information)
            Catch ex As Exception
                MsgBox("No record found for the specified username", MsgBoxStyle.Exclamation)
            End Try
        End Using
    End Sub
    Private Function ValidateForm() As Boolean
        If String.IsNullOrWhiteSpace(txtUsername.Text) OrElse String.IsNullOrWhiteSpace(txtNewPassword.Text) OrElse String.IsNullOrWhiteSpace(txtConfirmNewPassword.Text) Then
            MsgBox("Please fill the form", MsgBoxStyle.Exclamation)
            Return False
        End If

        If txtNewPassword.TextLength < 6 Then
            MsgBox("Password must be at least 6 characters", MsgBoxStyle.Exclamation)
            Return False
        End If

        If txtNewPassword.Text <> txtConfirmNewPassword.Text Then
            MsgBox("Password not same", MsgBoxStyle.Exclamation)
            Return False
        End If

        Return True
    End Function

End Class
