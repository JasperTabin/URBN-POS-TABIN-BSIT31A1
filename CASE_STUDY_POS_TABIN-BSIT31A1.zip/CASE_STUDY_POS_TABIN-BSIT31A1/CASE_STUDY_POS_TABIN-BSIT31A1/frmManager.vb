﻿Imports System.Data.OleDb

Public Class frmManager
    Private Sub frmManager_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
    End Sub

    Private Sub btnProducts_Click(sender As Object, e As EventArgs) Handles btnProducts.Click
        Dim productsForm As New frmProducts()
        productsForm.Show()
        Panel1.Controls.Clear()
        productsForm.Dock = DockStyle.Fill
        Panel1.Controls.Add(productsForm)
    End Sub

    Private Sub btnReports_Click(sender As Object, e As EventArgs) Handles btnReports.Click
        Dim ReportForm As New frmSalesReport()
        ReportForm.Show()
        Panel1.Controls.Clear()
        ReportForm.Dock = DockStyle.Fill
        Panel1.Controls.Add(ReportForm)
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        If MsgBox("You sure you wanna exit?", vbQuestion + vbYesNo) = vbYes Then
            Dim loginForm As frmLogin = New frmLogin()
            loginForm.RecordLogout(frmLogin.LoggedInUserName)

            MsgBox("Thanks for using Point of Sales System....")
            Me.Close()
            frmLogin.Close()
        End If
    End Sub

    Private Sub btnPOS_Click(sender As Object, e As EventArgs) Handles btnPOS.Click
        Dim posUpdateForm As New frmPOS()
        ' Show the form as a dialog
        If posUpdateForm.ShowDialog() = DialogResult.OK Then
            ' Handle any actions after the dialog is closed with OK button
        End If
    End Sub

End Class
