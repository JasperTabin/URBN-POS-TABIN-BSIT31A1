﻿Imports System.Data.OleDb

Public Class frmActivityLogs
    Private Sub frmActivityLogs_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        LoadActivityLogs()
    End Sub

    Private Sub LoadActivityLogs()
        Try
            ListView1.Items.Clear()
            Dim selectSql As String = "SELECT Username, TimeIn, TimeOut FROM tblActivity ORDER BY TimeIn ASC"
            Using cmd As New OleDbCommand(selectSql, cn)
                Dim reader As OleDbDataReader = cmd.ExecuteReader()

                While reader.Read()
                    Dim item As New ListViewItem(reader("Username").ToString())
                    item.SubItems.Add(reader("TimeIn").ToString())
                    item.SubItems.Add(If(reader("TimeOut") Is DBNull.Value, "", reader("TimeOut").ToString()))
                    ListView1.Items.Add(item)
                End While

                reader.Close()
            End Using
        Catch ex As Exception
            MsgBox($"An error occurred while loading activity logs: {ex.Message}", MsgBoxStyle.Critical)
        End Try
    End Sub
End Class
