﻿Imports System.Data.OleDb

Public Class frmProducts
    Private Sub frmProducts_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        Call LoadProducts()
        btnSave.Enabled = False
        btnUpdate.Enabled = False
        Call GetProductCode()
        Call getCategory()
        Call GetTotalProducts()
    End Sub

    Private Sub cleartext()
        txtPName.Clear()
        txtPdesc.Clear()
        txtAmount.Clear()
        txtcritical.Clear()
        txtQty.Clear()
    End Sub

    Private Sub txtSearch_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter Then
            ' Perform search and update the ListView
            SearchProductAndUpdateListView(txtSearch.Text)
        End If
    End Sub



    Private Sub SearchProductAndUpdateListView(searchText As String)
        ' Clear previous selection in the ListView
        ListView1.SelectedItems.Clear()

        ' Iterate through ListView items to find and highlight matching product
        For Each item As ListViewItem In ListView1.Items
            If String.Compare(item.SubItems(1).Text, searchText, StringComparison.OrdinalIgnoreCase) = 0 Then
                item.Selected = True

                item.EnsureVisible()

                txtSearch.Text = item.SubItems(1).Text


                txtPCode.Text = item.SubItems(0).Text
                txtPName.Text = item.SubItems(1).Text
                txtPdesc.Text = item.SubItems(2).Text
                cboCategory.Text = item.SubItems(3).Text
                txtAmount.Text = item.SubItems(4).Text
                txtQty.Text = item.SubItems(5).Text
                txtcritical.Text = item.SubItems(6).Text
                cboStatus.Text = item.SubItems(7).Text

                btnUpdate.Enabled = True


                Exit For
            End If
        Next
    End Sub


    Private Sub GetTotalProducts()
        ' Fetch the total number of products from the database
        sql = "SELECT COUNT(*) FROM qryProducts WHERE ProdName LIKE '%" & txtSearch.Text & "%'"
        cmd = New OleDbCommand(sql, cn)
        Dim totalProducts As Integer = Convert.ToInt32(cmd.ExecuteScalar())
        lblTotalProducts.Text = "Total Products: " & totalProducts.ToString()
    End Sub

    Private Sub GetProductCode()
        Using cmd As New OleDbCommand("SELECT ProductCode FROM tblProducts ORDER BY ProductCode DESC", cn)
            Using dr As OleDbDataReader = cmd.ExecuteReader()
                If dr.Read() Then
                    txtPCode.Text = (Convert.ToInt32(dr(0)) + 1).ToString()
                Else
                    txtPCode.Text = "100000"
                End If
            End Using
        End Using
    End Sub

    Private Sub LoadProducts()
        sql = "Select * from qryProducts"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        Dim x As ListViewItem
        ListView1.Items.Clear()
        Do While dr.Read = True
            x = New ListViewItem(dr(0).ToString) 'product code
            x.SubItems.Add(dr(1).ToString) 'name
            x.SubItems.Add(dr(2).ToString) 'description
            x.SubItems.Add(dr(3).ToString) 'category
            x.SubItems.Add(FormatCurrency(dr(4).ToString)) 'Amount
            x.SubItems.Add(dr(5).ToString) 'Qty
            x.SubItems.Add(dr(6).ToString) 'critical level
            x.SubItems.Add(dr(7).ToString) 'status
            ListView1.Items.Add(x)

        Loop
    End Sub

    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        btnSave.Enabled = True
        btnNew.Enabled = False

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        btnNew.Enabled = True
        btnSave.Enabled = False
        btnUpdate.Enabled = False
        Call cleartext()
        GetProductCode()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        If MsgBox("Do you want to add new product?", vbQuestion + vbYesNo) = vbYes Then
            If txtPCode.Text = "" Or txtPName.Text = "" Then
                MsgBox("Please complete the product information", MsgBoxStyle.Exclamation)
            Else
                sql = "Insert into tblProducts ([ProductCode],[ProdName],[ProdDescription],[Category],[Amount],[Quantity],[CriticalLevel],[Status])values([@ProductCode],[@ProdName],[@ProdDescription],[@Category],[@Amount],[@Quantity],[@CriticalLevel],[@Status])"
                cmd = New OleDbCommand(sql, cn)
                With cmd
                    .Parameters.AddWithValue("[@ProductCode]", txtPCode.Text) 'prod code
                    .Parameters.AddWithValue("[@ProdName]", txtPName.Text) 'name
                    .Parameters.AddWithValue("[@ProdDescription]", txtPdesc.Text) 'desc
                    .Parameters.AddWithValue("[@Category]", cboCategory.Text) 'category
                    .Parameters.AddWithValue("[@Amount]", txtAmount.Text) 'amount
                    .Parameters.AddWithValue("[@Quantity]", txtQty.Text) 'qty
                    .Parameters.AddWithValue("[@CriticalLevel]", txtcritical.Text) 'crit level
                    .Parameters.AddWithValue("[@Status", cboStatus.Text) 'status
                    .ExecuteNonQuery()

                End With
                MsgBox("New Product Successfully Save!!", MsgBoxStyle.Information)
            End If
        End If
        Call cleartext()
        Call LoadProducts()
        Call GetProductCode()


    End Sub

    Private Sub ListView1_DoubleClick(sender As Object, e As EventArgs) Handles ListView1.DoubleClick
        If ListView1.SelectedItems.Count > 0 Then
            txtPCode.Text = ListView1.SelectedItems(0).SubItems(0).Text
            txtPName.Text = ListView1.SelectedItems(0).SubItems(1).Text
            txtPdesc.Text = ListView1.SelectedItems(0).SubItems(2).Text
            cboCategory.Text = ListView1.SelectedItems(0).SubItems(3).Text
            txtAmount.Text = ListView1.SelectedItems(0).SubItems(4).Text
            txtQty.Text = ListView1.SelectedItems(0).SubItems(5).Text
            txtcritical.Text = ListView1.SelectedItems(0).SubItems(6).Text
            cboStatus.Text = ListView1.SelectedItems(0).SubItems(7).Text
            btnNew.Enabled = False
            btnUpdate.Enabled = True

        End If
    End Sub
    Private Sub getCategory()
        sql = "Select distinct Category from tblCategories"
        cmd = New OleDbCommand(sql, cn)
        Dim da As New OleDbDataAdapter(cmd)
        Dim dt As New DataTable
        da.Fill(dt)
        cboCategory.DataSource = dt
        cboCategory.DisplayMember = "Category"

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If MsgBox("Do you want to update the product?", vbQuestion + vbYesNo) = vbYes Then
            If txtPCode.Text = "" Or txtPName.Text = "" Then
                MsgBox("Please complete the product information", MsgBoxStyle.Exclamation)
            Else
                'sql = "Insert into tblProducts ([ProductCode],[ProdName],[ProdDescription],[Category],[Amount],[Quantity],[CriticalLevel],[Status])values([@ProductCode],[@ProdName],[@ProdDescription],[@Category],[@Amount],[@Quantity],[@CriticalLevel],[@Status])"

                sql = "Update tblProducts Set [ProdName]=[@ProdName],[ProdDescription]=[@ProdDescription],[Category]=[@Category],[Amount]=[@Amount],[Quantity]=[@Quantity],[CriticalLevel]=[@CriticalLevel],[Status]=[@Status] where [ProductCode]=[@ProductCode]"

                cmd = New OleDbCommand(sql, cn)
                With cmd
                    .Parameters.AddWithValue("[@ProdName]", txtPName.Text) 'name
                    .Parameters.AddWithValue("[@ProdDescription]", txtPdesc.Text) 'desc
                    .Parameters.AddWithValue("[@Category]", cboCategory.Text) 'category
                    .Parameters.AddWithValue("[@Amount]", txtAmount.Text) 'amount
                    .Parameters.AddWithValue("[@Quantity]", txtQty.Text) 'qty
                    .Parameters.AddWithValue("[@CriticalLevel]", txtcritical.Text) 'crit level
                    .Parameters.AddWithValue("[@Status", cboStatus.Text) 'status
                    .Parameters.AddWithValue("[@ProductCode]", txtPCode.Text) 'prod code
                    .ExecuteNonQuery()

                End With
                MsgBox("Product Successfully Updated!!", MsgBoxStyle.Information)
            End If
        End If
        Call cleartext()
        Call LoadProducts()
        Call GetProductCode()
    End Sub

End Class
