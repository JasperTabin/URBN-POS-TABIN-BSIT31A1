﻿Imports System.Data.OleDb

Public Class frmPayment
    ' Assuming you have an OleDbConnection named 'cn'
    ' Make sure to adjust the connection string and OleDbCommand parameters as needed

    Private Sub frmPayment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadPaymentModes()
    End Sub

    Private Sub LoadPaymentModes()
        Try
            ' Clear existing items in ListView
            ListViewPayment.Items.Clear()

            ' Retrieve payment modes from tblPaymentMode
            Dim selectSql As String = "SELECT PModeID, PaymentMode FROM tblPaymentMode ORDER BY PaymentMode"
            Using cmd As New OleDbCommand(selectSql, cn)
                Dim reader As OleDbDataReader = cmd.ExecuteReader()

                While reader.Read()
                    ' Create ListViewItem with data from database
                    Dim item As New ListViewItem(reader("PModeID").ToString())
                    item.SubItems.Add(reader("PaymentMode").ToString())

                    ' Add the item to ListView
                    ListViewPayment.Items.Add(item)
                End While

                reader.Close()
            End Using
        Catch ex As Exception
            MsgBox($"An error occurred while loading payment modes: {ex.Message}", MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub ListViewPayment_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListViewPayment.SelectedIndexChanged
        ' Display selected payment mode in txtPayment
        If ListViewPayment.SelectedItems.Count > 0 Then
            txtCategory.Text = ListViewPayment.SelectedItems(0).SubItems(1).Text
        End If
    End Sub

    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        ' Clear txtPayment for new entry
        txtCategory.Text = ""
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        ' Save new payment mode to tblPaymentMode
        Dim paymentMode As String = txtCategory.Text.Trim()

        If Not String.IsNullOrEmpty(paymentMode) Then
            Try
                Dim insertSql As String = "INSERT INTO tblPaymentMode (PaymentMode) VALUES (?)"
                Using cmd As New OleDbCommand(insertSql, cn)
                    cmd.Parameters.AddWithValue("@p1", paymentMode)
                    cmd.ExecuteNonQuery()
                End Using

                ' Reload payment modes in the ListView
                LoadPaymentModes()
            Catch ex As Exception
                MsgBox($"An error occurred while saving payment mode: {ex.Message}", MsgBoxStyle.Critical)
            End Try
        Else
            MsgBox("Payment mode cannot be empty.", MsgBoxStyle.Exclamation)
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        ' Update selected payment mode in tblPaymentMode
        If ListViewPayment.SelectedItems.Count > 0 Then
            Dim paymentMode As String = txtCategory.Text.Trim()

            If Not String.IsNullOrEmpty(paymentMode) Then
                Try
                    Dim updateSql As String = "UPDATE tblPaymentMode SET PaymentMode = ? WHERE PModeID = ?"
                    Using cmd As New OleDbCommand(updateSql, cn)
                        cmd.Parameters.AddWithValue("@p1", paymentMode)
                        cmd.Parameters.AddWithValue("@p2", ListViewPayment.SelectedItems(0).Text)
                        cmd.ExecuteNonQuery()
                    End Using

                    ' Reload payment modes in the ListView
                    LoadPaymentModes()
                Catch ex As Exception
                    MsgBox($"An error occurred while updating payment mode: {ex.Message}", MsgBoxStyle.Critical)
                End Try
            Else
                MsgBox("Payment mode cannot be empty.", MsgBoxStyle.Exclamation)
            End If
        Else
            MsgBox("Select a payment mode to update.", MsgBoxStyle.Exclamation)
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        ' Clear txtPayment and deselect ListViewPayment
        txtCategory.Text = ""
        ListViewPayment.SelectedItems.Clear()
    End Sub
End Class
