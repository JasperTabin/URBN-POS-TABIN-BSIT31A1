﻿Imports System.Data.OleDb

Public Class frmSalesReportDetails
    Private Sub frmSalesReportDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        Call loaditems()
    End Sub

    Private Sub loaditems()
        sql = "Select productCode,ProdName,Amount,Qty,Total from qrySalesDetails where transNo='" & lblTransno.Text & "'"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        Dim x As ListViewItem
        ListView1.Items.Clear()
        Do While dr.Read = True
            x = New ListViewItem(dr(0).ToString)
            x.SubItems.Add(dr(1).ToString)
            x.SubItems.Add(dr(2).ToString)
            x.SubItems.Add(dr(3).ToString)
            x.SubItems.Add(dr(4).ToString)
            x.SubItems.Add(dr(5).ToString)
            ListView1.Items.Add(x)
        Loop
        Call GetTotal()
        Call GetTotalitems()
    End Sub
    Private Sub GetTotal()
        Const col As Integer = 4
        Dim total As Integer
        Dim lvsi As ListViewItem.ListViewSubItem
        For i As Integer = 0 To ListView1.Items.Count - 1
            lvsi = ListView1.Items(i).SubItems(col)
            total += Double.Parse(lvsi.Text)
        Next
        lblTotal.Text = Format(Val(total), "0.00")
    End Sub

    Private Sub GetTotalitems()
        Const col As Integer = 3
        Dim total As Integer
        Dim lvsi As ListViewItem.ListViewSubItem
        For i As Integer = 0 To ListView1.Items.Count - 1
            lvsi = ListView1.Items(i).SubItems(col)
            total += Double.Parse(lvsi.Text)
        Next
        lblQty.Text = Val(total)
    End Sub

    Private Sub lblTransno_Click(sender As Object, e As EventArgs) Handles lblTransno.Click

    End Sub
End Class
