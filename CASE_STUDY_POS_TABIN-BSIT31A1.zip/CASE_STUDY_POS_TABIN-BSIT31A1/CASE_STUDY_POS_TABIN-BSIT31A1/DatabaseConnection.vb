﻿Imports System.Data.OleDb

Module DatabaseConnection
    Public cn As New OleDbConnection
    Public cmd As OleDbCommand
    Public dr As OleDbDataReader
    Public sql As String

    Public Sub Connection()
        cn.Close()
        'cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\tabin\Downloads\CASE STUDY-POS-LASTNAME-SECTION (3)\CASE STUDY-POS-LASTNAME-SECTION\CASE STUDY-POS-LASTNAME-SECTION\bin\Debug\POSdb.mdb"
        cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\Database1.accdb"
        cn.Open()
        'MsgBox("Connection Success")
    End Sub
End Module
