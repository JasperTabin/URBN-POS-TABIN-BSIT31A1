﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPOS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblCashier = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lbltime = New System.Windows.Forms.Label()
        Me.lbldate = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblUser = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnaddmop = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblchange = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cboMOP = New System.Windows.Forms.ComboBox()
        Me.txtref = New System.Windows.Forms.TextBox()
        Me.txtamountpaid = New System.Windows.Forms.TextBox()
        Me.lblTransNo = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboDiscount = New System.Windows.Forms.ComboBox()
        Me.lblDisc = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblVSales = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblTotalItems = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.lblVAT = New System.Windows.Forms.Label()
        Me.ListView2 = New System.Windows.Forms.ListView()
        Me.ColumnHeader9 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader10 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader14 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader15 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtstatus = New System.Windows.Forms.TextBox()
        Me.txtamount = New System.Windows.Forms.TextBox()
        Me.txtquantity = New System.Windows.Forms.TextBox()
        Me.txtproductname = New System.Windows.Forms.TextBox()
        Me.txtproductcode = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtcritlevel = New System.Windows.Forms.TextBox()
        Me.btncanceltrans = New System.Windows.Forms.Button()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.btnsavetransaction = New System.Windows.Forms.Button()
        Me.btnremoveproduct = New System.Windows.Forms.Button()
        Me.btnaddproduct = New System.Windows.Forms.Button()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblCashier
        '
        Me.lblCashier.AutoSize = True
        Me.lblCashier.Location = New System.Drawing.Point(1587, 748)
        Me.lblCashier.Name = "lblCashier"
        Me.lblCashier.Size = New System.Drawing.Size(39, 13)
        Me.lblCashier.TabIndex = 23
        Me.lblCashier.Text = "Label1"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'lbltime
        '
        Me.lbltime.AutoSize = True
        Me.lbltime.Font = New System.Drawing.Font("Copperplate Gothic Bold", 12.0!)
        Me.lbltime.ForeColor = System.Drawing.Color.White
        Me.lbltime.Location = New System.Drawing.Point(1124, 25)
        Me.lbltime.Name = "lbltime"
        Me.lbltime.Size = New System.Drawing.Size(56, 18)
        Me.lbltime.TabIndex = 130
        Me.lbltime.Text = "******"
        '
        'lbldate
        '
        Me.lbldate.AutoSize = True
        Me.lbldate.Font = New System.Drawing.Font("Copperplate Gothic Bold", 12.0!)
        Me.lbldate.ForeColor = System.Drawing.Color.White
        Me.lbldate.Location = New System.Drawing.Point(1067, 25)
        Me.lbldate.Name = "lbldate"
        Me.lbldate.Size = New System.Drawing.Size(56, 18)
        Me.lbldate.TabIndex = 129
        Me.lbldate.Text = "******"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Copperplate Gothic Bold", 12.0!)
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(913, 25)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(148, 18)
        Me.Label7.TabIndex = 128
        Me.Label7.Text = "DATE AND TIME"
        '
        'lblUser
        '
        Me.lblUser.AutoSize = True
        Me.lblUser.Font = New System.Drawing.Font("Copperplate Gothic Bold", 12.0!)
        Me.lblUser.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblUser.Location = New System.Drawing.Point(1270, 25)
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(12, 18)
        Me.lblUser.TabIndex = 122
        Me.lblUser.Text = "-"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(26, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.lblTotal)
        Me.GroupBox1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(984, 523)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(248, 86)
        Me.GroupBox1.TabIndex = 156
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GRAND TOTAL"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Verdana", 20.75!)
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(6, 28)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(32, 34)
        Me.Label10.TabIndex = 53
        Me.Label10.Text = "₱"
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Font = New System.Drawing.Font("Verdana", 20.75!)
        Me.lblTotal.ForeColor = System.Drawing.Color.White
        Me.lblTotal.Location = New System.Drawing.Point(35, 28)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(79, 34)
        Me.lblTotal.TabIndex = 30
        Me.lblTotal.Text = "0.00"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(26, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.Label20)
        Me.GroupBox2.Controls.Add(Me.Panel1)
        Me.GroupBox2.Controls.Add(Me.btnaddmop)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.lblchange)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.cboMOP)
        Me.GroupBox2.Controls.Add(Me.txtref)
        Me.GroupBox2.Controls.Add(Me.txtamountpaid)
        Me.GroupBox2.Controls.Add(Me.lblTransNo)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.cboDiscount)
        Me.GroupBox2.Controls.Add(Me.lblDisc)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.Panel2)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.lblVSales)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.lblTotalItems)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.lblVAT)
        Me.GroupBox2.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.White
        Me.GroupBox2.Location = New System.Drawing.Point(984, 98)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(248, 359)
        Me.GroupBox2.TabIndex = 155
        Me.GroupBox2.TabStop = False
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.ForeColor = System.Drawing.Color.White
        Me.Label22.Location = New System.Drawing.Point(144, 283)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(15, 16)
        Me.Label22.TabIndex = 56
        Me.Label22.Text = "₱"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.ForeColor = System.Drawing.Color.White
        Me.Label21.Location = New System.Drawing.Point(144, 259)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(15, 16)
        Me.Label21.TabIndex = 56
        Me.Label21.Text = "₱"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.ForeColor = System.Drawing.Color.White
        Me.Label20.Location = New System.Drawing.Point(144, 235)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(15, 16)
        Me.Label20.TabIndex = 56
        Me.Label20.Text = "₱"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Black
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.ForeColor = System.Drawing.Color.Black
        Me.Panel1.Location = New System.Drawing.Point(0, 58)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(247, 10)
        Me.Panel1.TabIndex = 39
        '
        'btnaddmop
        '
        Me.btnaddmop.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.btnaddmop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnaddmop.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnaddmop.ForeColor = System.Drawing.Color.Black
        Me.btnaddmop.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnaddmop.Location = New System.Drawing.Point(217, 150)
        Me.btnaddmop.Name = "btnaddmop"
        Me.btnaddmop.Size = New System.Drawing.Size(24, 24)
        Me.btnaddmop.TabIndex = 55
        Me.btnaddmop.Text = "+"
        Me.btnaddmop.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnaddmop.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(123, 130)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(15, 16)
        Me.Label1.TabIndex = 54
        Me.Label1.Text = "₱"
        '
        'lblchange
        '
        Me.lblchange.AutoSize = True
        Me.lblchange.Location = New System.Drawing.Point(140, 130)
        Me.lblchange.Name = "lblchange"
        Me.lblchange.Size = New System.Drawing.Size(36, 16)
        Me.lblchange.TabIndex = 53
        Me.lblchange.Text = "0.00"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(123, 103)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(15, 16)
        Me.Label2.TabIndex = 52
        Me.Label2.Text = "₱"
        '
        'cboMOP
        '
        Me.cboMOP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboMOP.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboMOP.FormattingEnabled = True
        Me.cboMOP.Location = New System.Drawing.Point(141, 150)
        Me.cboMOP.Name = "cboMOP"
        Me.cboMOP.Size = New System.Drawing.Size(76, 24)
        Me.cboMOP.TabIndex = 7
        '
        'txtref
        '
        Me.txtref.Enabled = False
        Me.txtref.Location = New System.Drawing.Point(141, 180)
        Me.txtref.Name = "txtref"
        Me.txtref.ReadOnly = True
        Me.txtref.Size = New System.Drawing.Size(101, 23)
        Me.txtref.TabIndex = 8
        '
        'txtamountpaid
        '
        Me.txtamountpaid.Location = New System.Drawing.Point(140, 100)
        Me.txtamountpaid.Name = "txtamountpaid"
        Me.txtamountpaid.Size = New System.Drawing.Size(100, 23)
        Me.txtamountpaid.TabIndex = 6
        Me.txtamountpaid.Text = "0.00"
        '
        'lblTransNo
        '
        Me.lblTransNo.AutoSize = True
        Me.lblTransNo.Font = New System.Drawing.Font("Verdana", 15.0!, System.Drawing.FontStyle.Bold)
        Me.lblTransNo.ForeColor = System.Drawing.Color.White
        Me.lblTransNo.Location = New System.Drawing.Point(70, 30)
        Me.lblTransNo.Name = "lblTransNo"
        Me.lblTransNo.Size = New System.Drawing.Size(110, 25)
        Me.lblTransNo.TabIndex = 49
        Me.lblTransNo.Text = "1000000"
        Me.lblTransNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 10.0!)
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(31, 13)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(177, 17)
        Me.Label3.TabIndex = 48
        Me.Label3.Text = "TRANSACTION NUMBER"
        '
        'cboDiscount
        '
        Me.cboDiscount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDiscount.Font = New System.Drawing.Font("Verdana", 10.0!)
        Me.cboDiscount.ForeColor = System.Drawing.Color.Black
        Me.cboDiscount.FormattingEnabled = True
        Me.cboDiscount.Items.AddRange(New Object() {"None", "Senior Citizen", "PWD"})
        Me.cboDiscount.Location = New System.Drawing.Point(126, 306)
        Me.cboDiscount.Name = "cboDiscount"
        Me.cboDiscount.Size = New System.Drawing.Size(114, 24)
        Me.cboDiscount.TabIndex = 9
        '
        'lblDisc
        '
        Me.lblDisc.AutoSize = True
        Me.lblDisc.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDisc.ForeColor = System.Drawing.Color.White
        Me.lblDisc.Location = New System.Drawing.Point(162, 283)
        Me.lblDisc.Name = "lblDisc"
        Me.lblDisc.Size = New System.Drawing.Size(36, 16)
        Me.lblDisc.TabIndex = 43
        Me.lblDisc.Text = "0.00"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(8, 309)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(112, 16)
        Me.Label17.TabIndex = 41
        Me.Label17.Text = "Discount Type :"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(8, 283)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(75, 16)
        Me.Label16.TabIndex = 40
        Me.Label16.Text = "Discount :"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Black
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.ForeColor = System.Drawing.Color.Black
        Me.Panel2.Location = New System.Drawing.Point(0, 214)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(247, 10)
        Me.Panel2.TabIndex = 38
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(8, 184)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(133, 16)
        Me.Label14.TabIndex = 39
        Me.Label14.Text = "Reference Number:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(7, 158)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(128, 16)
        Me.Label13.TabIndex = 38
        Me.Label13.Text = "Mode of Payment:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(7, 130)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(117, 16)
        Me.Label12.TabIndex = 37
        Me.Label12.Text = "Amount Change:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(7, 103)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(95, 16)
        Me.Label11.TabIndex = 36
        Me.Label11.Text = "Amount Paid:"
        '
        'lblVSales
        '
        Me.lblVSales.AutoSize = True
        Me.lblVSales.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVSales.ForeColor = System.Drawing.Color.White
        Me.lblVSales.Location = New System.Drawing.Point(162, 259)
        Me.lblVSales.Name = "lblVSales"
        Me.lblVSales.Size = New System.Drawing.Size(36, 16)
        Me.lblVSales.TabIndex = 35
        Me.lblVSales.Text = "0.00"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(6, 235)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(107, 16)
        Me.Label8.TabIndex = 34
        Me.Label8.Text = "Vatable Sales :"
        '
        'lblTotalItems
        '
        Me.lblTotalItems.AutoSize = True
        Me.lblTotalItems.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalItems.ForeColor = System.Drawing.Color.White
        Me.lblTotalItems.Location = New System.Drawing.Point(157, 75)
        Me.lblTotalItems.Name = "lblTotalItems"
        Me.lblTotalItems.Size = New System.Drawing.Size(15, 16)
        Me.lblTotalItems.TabIndex = 33
        Me.lblTotalItems.Text = "0"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(3, 75)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(147, 16)
        Me.Label9.TabIndex = 32
        Me.Label9.Text = "Total Products Sold :"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(6, 259)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(140, 16)
        Me.Label15.TabIndex = 31
        Me.Label15.Text = "VAT Amount(12%) :"
        '
        'lblVAT
        '
        Me.lblVAT.AutoSize = True
        Me.lblVAT.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVAT.ForeColor = System.Drawing.Color.White
        Me.lblVAT.Location = New System.Drawing.Point(162, 235)
        Me.lblVAT.Name = "lblVAT"
        Me.lblVAT.Size = New System.Drawing.Size(36, 16)
        Me.lblVAT.TabIndex = 30
        Me.lblVAT.Text = "0.00"
        '
        'ListView2
        '
        Me.ListView2.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader9, Me.ColumnHeader10, Me.ColumnHeader14, Me.ColumnHeader15, Me.ColumnHeader1})
        Me.ListView2.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListView2.FullRowSelect = True
        Me.ListView2.GridLines = True
        Me.ListView2.HideSelection = False
        Me.ListView2.Location = New System.Drawing.Point(187, 98)
        Me.ListView2.Name = "ListView2"
        Me.ListView2.Size = New System.Drawing.Size(736, 359)
        Me.ListView2.TabIndex = 154
        Me.ListView2.UseCompatibleStateImageBehavior = False
        Me.ListView2.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader9
        '
        Me.ColumnHeader9.Text = "Product Code"
        Me.ColumnHeader9.Width = 120
        '
        'ColumnHeader10
        '
        Me.ColumnHeader10.Text = "Product Name"
        Me.ColumnHeader10.Width = 180
        '
        'ColumnHeader14
        '
        Me.ColumnHeader14.Text = "Amount (₱)"
        Me.ColumnHeader14.Width = 100
        '
        'ColumnHeader15
        '
        Me.ColumnHeader15.Text = "Quantity"
        Me.ColumnHeader15.Width = 80
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Sub Total (₱)"
        Me.ColumnHeader1.Width = 120
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(600, 504)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(51, 16)
        Me.Label6.TabIndex = 153
        Me.Label6.Text = "Status"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(394, 504)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(57, 16)
        Me.Label4.TabIndex = 152
        Me.Label4.Text = "Amount"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(394, 576)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 16)
        Me.Label5.TabIndex = 149
        Me.Label5.Text = "Quantity"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(184, 576)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(99, 16)
        Me.Label19.TabIndex = 150
        Me.Label19.Text = "Product Name"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.White
        Me.Label23.Location = New System.Drawing.Point(184, 504)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(96, 16)
        Me.Label23.TabIndex = 151
        Me.Label23.Text = "Product Code"
        '
        'txtstatus
        '
        Me.txtstatus.Font = New System.Drawing.Font("Verdana", 10.75!)
        Me.txtstatus.ForeColor = System.Drawing.Color.Maroon
        Me.txtstatus.Location = New System.Drawing.Point(603, 523)
        Me.txtstatus.Name = "txtstatus"
        Me.txtstatus.ReadOnly = True
        Me.txtstatus.Size = New System.Drawing.Size(157, 25)
        Me.txtstatus.TabIndex = 148
        Me.txtstatus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtamount
        '
        Me.txtamount.Font = New System.Drawing.Font("Verdana", 10.75!)
        Me.txtamount.ForeColor = System.Drawing.Color.Maroon
        Me.txtamount.Location = New System.Drawing.Point(397, 523)
        Me.txtamount.Name = "txtamount"
        Me.txtamount.ReadOnly = True
        Me.txtamount.Size = New System.Drawing.Size(147, 25)
        Me.txtamount.TabIndex = 147
        Me.txtamount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtquantity
        '
        Me.txtquantity.Font = New System.Drawing.Font("Verdana", 10.75!)
        Me.txtquantity.ForeColor = System.Drawing.Color.Maroon
        Me.txtquantity.Location = New System.Drawing.Point(397, 595)
        Me.txtquantity.Name = "txtquantity"
        Me.txtquantity.ReadOnly = True
        Me.txtquantity.Size = New System.Drawing.Size(147, 25)
        Me.txtquantity.TabIndex = 145
        Me.txtquantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtproductname
        '
        Me.txtproductname.Font = New System.Drawing.Font("Verdana", 10.75!)
        Me.txtproductname.Location = New System.Drawing.Point(187, 595)
        Me.txtproductname.Name = "txtproductname"
        Me.txtproductname.ReadOnly = True
        Me.txtproductname.Size = New System.Drawing.Size(151, 25)
        Me.txtproductname.TabIndex = 146
        '
        'txtproductcode
        '
        Me.txtproductcode.Font = New System.Drawing.Font("Verdana", 10.75!)
        Me.txtproductcode.ForeColor = System.Drawing.Color.Red
        Me.txtproductcode.Location = New System.Drawing.Point(187, 523)
        Me.txtproductcode.Name = "txtproductcode"
        Me.txtproductcode.Size = New System.Drawing.Size(151, 25)
        Me.txtproductcode.TabIndex = 144
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Verdana", 7.75!)
        Me.Label24.ForeColor = System.Drawing.Color.White
        Me.Label24.Location = New System.Drawing.Point(601, 579)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(81, 13)
        Me.Label24.TabIndex = 158
        Me.Label24.Text = "Critical Level"
        '
        'txtcritlevel
        '
        Me.txtcritlevel.Font = New System.Drawing.Font("Verdana", 10.75!)
        Me.txtcritlevel.ForeColor = System.Drawing.Color.Maroon
        Me.txtcritlevel.Location = New System.Drawing.Point(603, 595)
        Me.txtcritlevel.Name = "txtcritlevel"
        Me.txtcritlevel.ReadOnly = True
        Me.txtcritlevel.Size = New System.Drawing.Size(157, 25)
        Me.txtcritlevel.TabIndex = 157
        Me.txtcritlevel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btncanceltrans
        '
        Me.btncanceltrans.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncanceltrans.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncanceltrans.ForeColor = System.Drawing.Color.White
        Me.btncanceltrans.Image = Global.CASE_STUDY_POS_TABIN_BSIT31A1.My.Resources.Resources.Cancel_Icon
        Me.btncanceltrans.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btncanceltrans.Location = New System.Drawing.Point(29, 317)
        Me.btncanceltrans.Name = "btncanceltrans"
        Me.btncanceltrans.Size = New System.Drawing.Size(106, 67)
        Me.btncanceltrans.TabIndex = 143
        Me.btncanceltrans.Text = "CANCEL"
        Me.btncanceltrans.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btncanceltrans.UseVisualStyleBackColor = True
        '
        'btnLogout
        '
        Me.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogout.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogout.ForeColor = System.Drawing.Color.White
        Me.btnLogout.Image = Global.CASE_STUDY_POS_TABIN_BSIT31A1.My.Resources.Resources.Exit_Icon
        Me.btnLogout.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnLogout.Location = New System.Drawing.Point(29, 609)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Size = New System.Drawing.Size(106, 67)
        Me.btnLogout.TabIndex = 142
        Me.btnLogout.Text = "LOGOUT"
        Me.btnLogout.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnLogout.UseVisualStyleBackColor = True
        '
        'btnsavetransaction
        '
        Me.btnsavetransaction.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsavetransaction.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsavetransaction.ForeColor = System.Drawing.Color.White
        Me.btnsavetransaction.Image = Global.CASE_STUDY_POS_TABIN_BSIT31A1.My.Resources.Resources.Save_Icon
        Me.btnsavetransaction.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnsavetransaction.Location = New System.Drawing.Point(29, 244)
        Me.btnsavetransaction.Name = "btnsavetransaction"
        Me.btnsavetransaction.Size = New System.Drawing.Size(106, 67)
        Me.btnsavetransaction.TabIndex = 141
        Me.btnsavetransaction.Text = "SAVE"
        Me.btnsavetransaction.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnsavetransaction.UseVisualStyleBackColor = True
        '
        'btnremoveproduct
        '
        Me.btnremoveproduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnremoveproduct.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnremoveproduct.ForeColor = System.Drawing.Color.White
        Me.btnremoveproduct.Image = Global.CASE_STUDY_POS_TABIN_BSIT31A1.My.Resources.Resources.Remove_Icon1
        Me.btnremoveproduct.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnremoveproduct.Location = New System.Drawing.Point(29, 171)
        Me.btnremoveproduct.Name = "btnremoveproduct"
        Me.btnremoveproduct.Size = New System.Drawing.Size(106, 67)
        Me.btnremoveproduct.TabIndex = 139
        Me.btnremoveproduct.Text = "REMOVE"
        Me.btnremoveproduct.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnremoveproduct.UseVisualStyleBackColor = True
        '
        'btnaddproduct
        '
        Me.btnaddproduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnaddproduct.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnaddproduct.ForeColor = System.Drawing.Color.White
        Me.btnaddproduct.Image = Global.CASE_STUDY_POS_TABIN_BSIT31A1.My.Resources.Resources.AddToCart_Icon
        Me.btnaddproduct.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnaddproduct.Location = New System.Drawing.Point(29, 98)
        Me.btnaddproduct.Name = "btnaddproduct"
        Me.btnaddproduct.Size = New System.Drawing.Size(106, 67)
        Me.btnaddproduct.TabIndex = 138
        Me.btnaddproduct.Text = "ADD TO CART"
        Me.btnaddproduct.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnaddproduct.UseVisualStyleBackColor = True
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(41, Byte), Integer))
        Me.PictureBox3.Location = New System.Drawing.Point(162, 17)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(2, 41)
        Me.PictureBox3.TabIndex = 137
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(41, Byte), Integer))
        Me.PictureBox4.Location = New System.Drawing.Point(1226, 15)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(2, 41)
        Me.PictureBox4.TabIndex = 136
        Me.PictureBox4.TabStop = False
        '
        'PictureBox14
        '
        Me.PictureBox14.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(26, Byte), Integer))
        Me.PictureBox14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox14.Image = Global.CASE_STUDY_POS_TABIN_BSIT31A1.My.Resources.Resources.Username_Icon
        Me.PictureBox14.Location = New System.Drawing.Point(1234, 17)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(30, 31)
        Me.PictureBox14.TabIndex = 135
        Me.PictureBox14.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.CASE_STUDY_POS_TABIN_BSIT31A1.My.Resources.Resources.POS_Icon
        Me.PictureBox2.Location = New System.Drawing.Point(6, 11)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(53, 51)
        Me.PictureBox2.TabIndex = 133
        Me.PictureBox2.TabStop = False
        '
        'PictureBox13
        '
        Me.PictureBox13.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(41, Byte), Integer))
        Me.PictureBox13.Location = New System.Drawing.Point(-1, 66)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(1572, 2)
        Me.PictureBox13.TabIndex = 132
        Me.PictureBox13.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(26, Byte), Integer))
        Me.PictureBox1.Location = New System.Drawing.Point(-1, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1391, 62)
        Me.PictureBox1.TabIndex = 131
        Me.PictureBox1.TabStop = False
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(26, Byte), Integer))
        Me.Label18.Font = New System.Drawing.Font("Copperplate Gothic Bold", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Transparent
        Me.Label18.Location = New System.Drawing.Point(71, 26)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(79, 24)
        Me.Label18.TabIndex = 159
        Me.Label18.Text = "URBN"
        '
        'frmPOS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(26, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1387, 709)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.txtcritlevel)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.ListView2)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.txtstatus)
        Me.Controls.Add(Me.txtamount)
        Me.Controls.Add(Me.txtquantity)
        Me.Controls.Add(Me.txtproductname)
        Me.Controls.Add(Me.txtproductcode)
        Me.Controls.Add(Me.btncanceltrans)
        Me.Controls.Add(Me.btnLogout)
        Me.Controls.Add(Me.btnsavetransaction)
        Me.Controls.Add(Me.btnremoveproduct)
        Me.Controls.Add(Me.btnaddproduct)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox14)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox13)
        Me.Controls.Add(Me.lbltime)
        Me.Controls.Add(Me.lbldate)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.lblUser)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblCashier)
        Me.Name = "frmPOS"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmPOS"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblCashier As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox14 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox13 As PictureBox
    Friend WithEvents lbltime As Label
    Friend WithEvents lbldate As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lblUser As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btncanceltrans As Button
    Friend WithEvents btnLogout As Button
    Friend WithEvents btnsavetransaction As Button
    Friend WithEvents btnremoveproduct As Button
    Friend WithEvents btnaddproduct As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label10 As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnaddmop As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents lblchange As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cboMOP As ComboBox
    Friend WithEvents txtref As TextBox
    Friend WithEvents txtamountpaid As TextBox
    Friend WithEvents lblTransNo As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents cboDiscount As ComboBox
    Friend WithEvents lblDisc As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents lblVSales As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents lblTotalItems As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents lblVAT As Label
    Friend WithEvents ListView2 As ListView
    Friend WithEvents ColumnHeader9 As ColumnHeader
    Friend WithEvents ColumnHeader10 As ColumnHeader
    Friend WithEvents ColumnHeader14 As ColumnHeader
    Friend WithEvents ColumnHeader15 As ColumnHeader
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents Label6 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents txtstatus As TextBox
    Friend WithEvents txtamount As TextBox
    Friend WithEvents txtquantity As TextBox
    Friend WithEvents txtproductname As TextBox
    Friend WithEvents txtproductcode As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents txtcritlevel As TextBox
    Friend WithEvents Label18 As Label
End Class
