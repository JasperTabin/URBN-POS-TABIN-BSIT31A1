﻿Imports System.Data.OleDb
Imports System.Text

Public Class frmUsers
    Private Sub frmUsers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        Call LoadUsers()
        btnSave.Enabled = False
        btnUpdate.Enabled = False

        Call UpdateTotalUsers()

    End Sub

    Private Sub UpdateTotalUsers()
        ' Fetch the total number of users from the database
        sql = "SELECT COUNT(*) FROM tblUsers"
        cmd = New OleDbCommand(sql, cn)
        Dim totalUsers As Integer = Convert.ToInt32(cmd.ExecuteScalar())
        lblTotal.Text = "Total Users: " & totalUsers.ToString()
    End Sub

    Private Sub LoadUsers()
        ' Load all users into the ListView
        sql = "Select * from tblUsers"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        Dim x As ListViewItem
        ListView1.Items.Clear()

        Do While dr.Read = True
            x = New ListViewItem(dr("UserID").ToString())
            x.SubItems.Add(dr("Username").ToString())
            x.SubItems.Add(dr("Password").ToString())
            x.SubItems.Add(dr("Role").ToString())
            x.SubItems.Add(dr("LastName").ToString())
            x.SubItems.Add(dr("FirstName").ToString())
            x.SubItems.Add(dr("Status").ToString())
            ListView1.Items.Add(x)
        Loop
    End Sub


    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If MsgBox("Do you want to add new user?", vbQuestion + vbYesNo) = vbYes Then
            If txtusername.Text = "" Or txtpassword.Text = "" Or txtconfirmpassword.Text = "" Or txtlastname.Text = "" Or txtfirstname.Text = "" Then
                MsgBox("Please complete the information", MsgBoxStyle.Exclamation)
            ElseIf txtpassword.Text <> txtconfirmpassword.Text Then
                MsgBox("Password and confirmed password must be matched!!")
            Else

            End If
        End If

        Call UpdateTotalUsers()

    End Sub

    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        btnNew.Enabled = False
        btnSave.Enabled = True

        txtuserId.Clear()
        txtusername.Clear()
        txtpassword.Clear()
        txtconfirmpassword.Clear()
        cboRole.SelectedIndex = -1
        txtlastname.Clear()
        txtfirstname.Clear()
        cboStatus.SelectedIndex = -1
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        btnNew.Enabled = True
        btnSave.Enabled = False
        btnUpdate.Enabled = False

    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        If ListView1.SelectedItems.Count > 0 Then
            ' Get the selected item
            Dim selectedItem As ListViewItem = ListView1.SelectedItems(0)

            ' Display data in textboxes and combo boxes
            txtuserId.Text = selectedItem.SubItems(0).Text
            txtusername.Text = selectedItem.SubItems(1).Text
            txtpassword.Text = selectedItem.SubItems(2).Text
            cboRole.Text = selectedItem.SubItems(3).Text
            txtlastname.Text = selectedItem.SubItems(4).Text
            txtfirstname.Text = selectedItem.SubItems(5).Text
            cboStatus.Text = selectedItem.SubItems(6).Text

            ' Enable Update and Cancel buttons
            btnUpdate.Enabled = True
            btnCancel.Enabled = True
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If MsgBox("Do you want to update the user information?", vbQuestion + vbYesNo) = vbYes Then
            If txtusername.Text = "" Or txtpassword.Text = "" Or txtconfirmpassword.Text = "" Or txtlastname.Text = "" Or txtfirstname.Text = "" Then
                MsgBox("Please complete the information", MsgBoxStyle.Exclamation)
            ElseIf txtpassword.Text <> txtconfirmpassword.Text Then
                MsgBox("Password and confirmed password must be matched!!")
            Else
                Dim updateSql As String = "UPDATE tblUsers SET " &
                    "Username = @Username, [Password] = @Password, Role = @Role, " &
                    "LastName = @LastName, FirstName = @FirstName, Status = @Status " &
                    "WHERE UserID = @UserID"

                Using cmdUpdate As New OleDbCommand(updateSql, cn)
                    cmdUpdate.Parameters.AddWithValue("@Username", txtusername.Text)
                    cmdUpdate.Parameters.AddWithValue("@Password", txtpassword.Text)
                    cmdUpdate.Parameters.AddWithValue("@Role", cboRole.Text)
                    cmdUpdate.Parameters.AddWithValue("@LastName", txtlastname.Text)
                    cmdUpdate.Parameters.AddWithValue("@FirstName", txtfirstname.Text)
                    cmdUpdate.Parameters.AddWithValue("@Status", cboStatus.Text)
                    cmdUpdate.Parameters.AddWithValue("@UserID", txtuserId.Text)
                    cmdUpdate.ExecuteNonQuery()
                    MsgBox("User information updated successfully!", MsgBoxStyle.Information)
                    LoadUsers()
                End Using
            End If
        End If

        Call UpdateTotalUsers()
    End Sub

    Private Sub txtSearch_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter Then
            ' Perform search and update the ListView
            SearchUserAndUpdateListView(txtSearch.Text)
        End If
    End Sub

    Private Sub SearchUserAndUpdateListView(searchText As String)
        ' Clear previous selection in the ListView
        ListView1.SelectedItems.Clear()

        ' Iterate through ListView items to find and highlight matching user
        For Each item As ListViewItem In ListView1.Items
            If String.Compare(item.SubItems(1).Text, searchText, StringComparison.OrdinalIgnoreCase) = 0 Then
                ' Compare usernames in a case-insensitive manner for an exact match
                item.Selected = True
                ' Scroll to the selected item to make it visible
                item.EnsureVisible()
                Exit For ' Assuming you want to highlight the first matching user only
            End If
        Next
    End Sub


End Class
