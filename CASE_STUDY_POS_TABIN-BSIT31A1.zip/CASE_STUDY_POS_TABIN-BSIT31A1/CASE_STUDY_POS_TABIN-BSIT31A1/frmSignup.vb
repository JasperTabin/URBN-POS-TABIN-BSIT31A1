﻿Imports System.Data.OleDb
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Button

Public Class frmSignup
    Private Sub frmSignup_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        InitializeTextBoxes()
        StyleButton(btnCreate)
        StyleButton(btnClear)
        LinkLabel3.LinkBehavior = LinkBehavior.NeverUnderline
    End Sub

    Private Sub InitializeTextBoxes()
        Dim placeholders() As String = {"First Name", "Last Name", "Username", "Password", "Confirm Password"}
        Dim textBoxes() As TextBox = {txtFirstname, txtLastname, txtUsername, txtPassword, txtConfirmPassword}

        For i As Integer = 0 To placeholders.Length - 1
            Dim placeholder = placeholders(i)
            Dim textBox = textBoxes(i)

            SetPlaceholder(textBox, placeholder)
            AddHandler textBox.MouseEnter, Sub(sender, e) SetMouseEnter(sender, placeholder)
            AddHandler textBox.MouseLeave, Sub(sender, e) SetMouseLeave(sender, placeholder)
            AddHandler textBox.KeyPress, Sub(sender, e) PreventEditing(sender, placeholder, e)
        Next
    End Sub


    Private Sub SetMouseEnter(textBox As TextBox, placeholder As String)
        If textBox.Text = placeholder Then
            textBox.Text = ""
            textBox.ForeColor = Color.White
        End If
    End Sub

    Private Sub SetMouseLeave(textBox As TextBox, placeholder As String)
        If textBox.Text = "" Then
            SetPlaceholder(textBox, placeholder)
        End If
    End Sub

    Private Sub SetPlaceholder(textBox As TextBox, placeholder As String)
        textBox.Text = placeholder
        textBox.ForeColor = Color.Gray
    End Sub

    Private Sub PreventEditing(textBox As TextBox, placeholder As String, e As KeyPressEventArgs)
        If textBox.Text = placeholder Then
            e.Handled = True
        End If
    End Sub

    Private Sub StyleButton(button As Button)
        button.FlatStyle = FlatStyle.Flat
        button.FlatAppearance.BorderSize = 0
        button.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255)
        button.BackColor = Color.FromArgb(127, 90, 240)
        ''button.FlatAppearance.MouseOverBackColor = Color.FromArgb(22, 22, 26)
        button.FlatAppearance.MouseDownBackColor = Color.FromArgb(114, 117, 126)

        Dim cornerRadius As Integer = 25
        Dim buttonPath As New Drawing2D.GraphicsPath()
        buttonPath.AddArc(0, 0, cornerRadius * 2, cornerRadius * 2, 180, 90)
        buttonPath.AddArc(button.Width - cornerRadius * 2, 0, cornerRadius * 2, cornerRadius * 2, 270, 90)
        buttonPath.AddArc(button.Width - cornerRadius * 2, button.Height - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 0, 90)
        buttonPath.AddArc(0, button.Height - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 90, 90)
        button.Region = New Drawing.Region(buttonPath)
    End Sub

    Private Sub SetLinkLabelStyle(linkLabel As LinkLabel)
        linkLabel.LinkBehavior = LinkBehavior.NeverUnderline
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        ' Always show the password as "●"
        If CheckBox1.Checked Then
            txtPassword.PasswordChar = ControlChars.NullChar
            txtConfirmPassword.PasswordChar = ControlChars.NullChar
        Else
            txtPassword.PasswordChar = "●"
            txtConfirmPassword.PasswordChar = "●"
        End If
    End Sub

    Private Sub txtPassword_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged
        ' Set PasswordChar to "●" when typing the password
        If txtPassword.Text = "Password" Then
            txtPassword.PasswordChar = ControlChars.NullChar
        Else
            txtPassword.PasswordChar = "●"
        End If
    End Sub

    Private Sub txtConfirmPassword_TextChanged(sender As Object, e As EventArgs) Handles txtConfirmPassword.TextChanged
        ' Set PasswordChar to "●" when typing the password
        If txtConfirmPassword.Text = "Confirm Password" Then
            txtConfirmPassword.PasswordChar = ControlChars.NullChar
        Else
            txtConfirmPassword.PasswordChar = "●"
        End If
    End Sub



    'Above is Design Below are Functions

    'Button Clear
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtFirstname.Clear()
        txtLastname.Clear()
        txtUsername.Clear()
        txtPassword.Clear()
        txtConfirmPassword.Clear()
    End Sub

    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        checkifexist()
    End Sub

    Private Sub saveData()
        ' Set the default status as "Active" for new accounts
        Dim defaultStatus As String = "Active"

        ' SQL query to insert data including the status
        sql = "INSERT INTO tblUsers([Username],[Password],[Firstname],[Lastname],[Role],[Status]) VALUES (@Username, @Password, @Firstname, @Lastname, @Role, @Status)"
        cmd = New OleDbCommand(sql, cn)

        ' Add parameters for the query
        With cmd
            .Parameters.AddWithValue("@Username", txtUsername.Text)
            .Parameters.AddWithValue("@Password", txtPassword.Text)
            .Parameters.AddWithValue("@Firstname", txtFirstname.Text)
            .Parameters.AddWithValue("@Lastname", txtLastname.Text)
            .Parameters.AddWithValue("@Role", cborole.Text)
            .Parameters.AddWithValue("@Status", defaultStatus)
            .ExecuteNonQuery()
        End With

        MsgBox("Account Created", vbInformation)
    End Sub

    Private Sub checkifexist()
        If ValidateForm() Then
            sql = "Select Username from tblUsers where Username='" & txtUsername.Text & "'"
            cmd = New OleDbCommand(sql, cn)
            dr = cmd.ExecuteReader

            If dr.HasRows Then
                MsgBox("Username Already Exists", vbExclamation)
            Else
                saveData()
            End If
        End If
    End Sub

    Private Function ValidateForm() As Boolean
        Dim textBoxes() As TextBox = {txtFirstname, txtLastname, txtUsername, txtPassword, txtConfirmPassword}

        For Each textBox As TextBox In textBoxes
            Dim placeholder As String = TryCast(textBox.Tag, String)

            If String.IsNullOrEmpty(textBox.Text) OrElse textBox.Text = placeholder Then
                MsgBox("Please fill the form", vbExclamation)
                Return False
            End If
        Next

        If txtPassword.Text = "Password" OrElse txtConfirmPassword.Text = "Confirm Password" Then
            MsgBox("Please fill the form", vbExclamation)
            Return False
        End If

        If txtPassword.Text <> txtConfirmPassword.Text Then
            MsgBox("Password not same", vbExclamation)
            Return False
        End If

        If txtPassword.TextLength < 6 Then
            MsgBox("Password must be at least 6 characters", vbExclamation)
            Return False
        End If

        Return True
    End Function

    Private Sub LinkLabel3_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        frmLogin.Show()
        Me.Hide()
    End Sub
End Class