﻿Imports System.Data.OleDb

Public Class frmCategories
    Private Sub frmCategories_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Connection()
        Call LoadCategories()
    End Sub

    Private Sub LoadCategories()
        Try
            ' Clear existing items in ListView
            ListViewCategory.Items.Clear()

            ' Retrieve categories from tblCategories
            Dim selectSql As String = "SELECT CategoryID, Category FROM tblCategories ORDER BY Category"
            Using cmd As New OleDbCommand(selectSql, cn)
                Dim reader As OleDbDataReader = cmd.ExecuteReader()

                While reader.Read()
                    ' Create ListViewItem with data from database
                    Dim item As New ListViewItem(reader("CategoryID").ToString())
                    item.SubItems.Add(reader("Category").ToString())

                    ' Add the item to ListView
                    ListViewCategory.Items.Add(item)
                End While

                reader.Close()
            End Using
        Catch ex As Exception
            MsgBox($"An error occurred while loading categories: {ex.Message}", MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub ListViewCategories_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListViewCategory.SelectedIndexChanged
        ' Display selected category in txtCategory
        If ListViewCategory.SelectedItems.Count > 0 Then
            txtCategory.Text = ListViewCategory.SelectedItems(0).SubItems(1).Text
        End If
    End Sub

    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        ' Clear txtCategory for new entry
        txtCategory.Text = ""
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        ' Save new category to tblCategories
        Dim category As String = txtCategory.Text.Trim()

        If Not String.IsNullOrEmpty(category) Then
            Try
                Dim insertSql As String = "INSERT INTO tblCategories (Category) VALUES (?)"
                Using cmd As New OleDbCommand(insertSql, cn)
                    cmd.Parameters.AddWithValue("@p1", category)
                    cmd.ExecuteNonQuery()
                End Using

                ' Reload categories in the ListView
                LoadCategories()
            Catch ex As Exception
                MsgBox($"An error occurred while saving category: {ex.Message}", MsgBoxStyle.Critical)
            End Try
        Else
            MsgBox("Category cannot be empty.", MsgBoxStyle.Exclamation)
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        ' Update selected category in tblCategories
        If ListViewCategory.SelectedItems.Count > 0 Then
            Dim category As String = txtCategory.Text.Trim()

            If Not String.IsNullOrEmpty(category) Then
                Try
                    Dim updateSql As String = "UPDATE tblCategories SET Category = ? WHERE CategoryID = ?"
                    Using cmd As New OleDbCommand(updateSql, cn)
                        cmd.Parameters.AddWithValue("@p1", category)
                        cmd.Parameters.AddWithValue("@p2", ListViewCategory.SelectedItems(0).Text)
                        cmd.ExecuteNonQuery()
                    End Using

                    ' Reload categories in the ListView
                    LoadCategories()
                Catch ex As Exception
                    MsgBox($"An error occurred while updating category: {ex.Message}", MsgBoxStyle.Critical)
                End Try
            Else
                MsgBox("Category cannot be empty.", MsgBoxStyle.Exclamation)
            End If
        Else
            MsgBox("Select a category to update.", MsgBoxStyle.Exclamation)
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        ' Clear txtCategory and deselect ListViewCategories
        txtCategory.Text = ""
        ListViewCategory.SelectedItems.Clear()
    End Sub

End Class
