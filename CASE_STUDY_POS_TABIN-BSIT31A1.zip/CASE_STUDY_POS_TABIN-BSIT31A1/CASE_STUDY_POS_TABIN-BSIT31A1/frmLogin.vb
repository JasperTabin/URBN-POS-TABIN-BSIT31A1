﻿Imports System.Data.OleDb
Imports System.Drawing.Drawing2D


Public Class frmLogin
    Private Shared _loggedInUserName As String

    Public Shared Property LoggedInUserName As String
        Get
            Return _loggedInUserName
        End Get
        Set(value As String)
            _loggedInUserName = value
        End Set
    End Property


    Private Sub frmLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        InitializeTextBox(txtUsername, "Username")
        InitializeTextBox(txtPassword, "Password")
        SetLinkLabelStyle(LinkLabel1)
        SetLinkLabelStyle(LinkLabel2)
        Call Connection()
        StyleButton(btnLogin)
    End Sub

    Private Sub InitializeTextBox(textBox As TextBox, placeholder As String)
        SetPlaceholder(textBox, placeholder)
        AddHandler textBox.MouseEnter, Sub() SetMouseEnter(textBox, placeholder)
        AddHandler textBox.MouseLeave, Sub() SetMouseLeave(textBox, placeholder)
        AddHandler textBox.KeyPress, Sub(sender, e) PreventEditing(sender, placeholder, e)
    End Sub

    Private Sub SetMouseEnter(textBox As TextBox, placeholder As String)
        If textBox.Text = placeholder Then
            SetPlaceholder(textBox, "")
            textBox.ForeColor = Color.White
        End If
    End Sub

    Private Sub SetMouseLeave(textBox As TextBox, placeholder As String)
        If textBox.Text = "" Then
            SetPlaceholder(textBox, placeholder)
        End If
    End Sub

    Private Sub SetPlaceholder(textBox As TextBox, placeholder As String)
        textBox.Text = placeholder
        textBox.ForeColor = If(placeholder = "", Color.White, Color.Gray)
    End Sub

    Private Sub PreventEditing(textBox As TextBox, placeholder As String, e As KeyPressEventArgs)
        If textBox.Text = placeholder Then
            e.Handled = True
        End If
    End Sub

    Private Sub SetLinkLabelStyle(linkLabel As LinkLabel)
        linkLabel.LinkBehavior = LinkBehavior.NeverUnderline
    End Sub

    Private Sub StyleButton(button As Button)
        button.FlatStyle = FlatStyle.Flat
        button.FlatAppearance.BorderSize = 0
        button.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255)
        button.BackColor = Color.FromArgb(127, 90, 240)
        'button.FlatAppearance.MouseOverBackColor = Color.SteelBlue
        button.FlatAppearance.MouseDownBackColor = Color.FromArgb(114, 117, 126)

        Dim cornerRadius As Integer = 25
        Dim buttonPath As New GraphicsPath()
        buttonPath.AddArc(0, 0, cornerRadius * 2, cornerRadius * 2, 180, 90)
        buttonPath.AddArc(button.Width - cornerRadius * 2, 0, cornerRadius * 2, cornerRadius * 2, 270, 90)
        buttonPath.AddArc(button.Width - cornerRadius * 2, button.Height - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 0, 90)
        buttonPath.AddArc(0, button.Height - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 90, 90)
        button.Region = New Region(buttonPath)
    End Sub

    Private Sub txtPassword_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged
        If txtPassword.Text = "Password" Then
            txtPassword.PasswordChar = ControlChars.NullChar
        Else
            txtPassword.PasswordChar = If(CheckBox1.Checked, ControlChars.NullChar, "●")
        End If
    End Sub


    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        txtPassword.PasswordChar = If(CheckBox1.Checked, ControlChars.NullChar, "●")
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        ' Show the signup form
        Dim frmSignupForm As New frmSignup()
        frmSignupForm.Show()

        ' Hide the current login form
        Me.Hide()
    End Sub


    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs)
        frmChangePassword.ShowDialog()
    End Sub

    ''
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Try
            Dim userStatus As String = GetUserStatus(txtUsername.Text, txtPassword.Text)

            If userStatus = "Active" Then
                ' User is active, proceed with login
                Dim userRole As String = GetUserRole(txtUsername.Text, txtPassword.Text)

                If userRole = "Cashier" OrElse userRole = "Manager" OrElse userRole = "Admin" Then
                    ' Set the logged-in username in the shared property
                    frmLogin.LoggedInUserName = txtUsername.Text

                    RecordActivity(txtUsername.Text, "Login")

                    If userRole = "Manager" Then
                        Dim frmManagerForm As New frmManager()
                        frmManagerForm.Show()
                    ElseIf userRole = "Cashier" Then
                        Dim frmPOS As New frmPOS()
                        frmPOS.Show()
                    ElseIf userRole = "Admin" Then
                        Dim frmDashBoard As New frmDashBoard(txtUsername.Text, userRole)
                        frmDashBoard.Show()
                    End If

                    Me.Hide()
                Else
                    MsgBox("Unknown user role. Please contact support.", MsgBoxStyle.Critical)
                End If
            ElseIf userStatus = "Disabled" Then
                MsgBox("Your account is disabled. You can't login.", MsgBoxStyle.Critical)
            Else
                MsgBox("Login Failed", MsgBoxStyle.Critical)
                lblattempts.Text = CInt(lblattempts.Text) - 1
                If CInt(lblattempts.Text) = 0 Then
                    MsgBox("You reached the maximum attempt limits", MsgBoxStyle.Critical)
                    DisabledAccount(txtUsername.Text)
                End If
            End If
        Catch ex As Exception
            MsgBox($"An error occurred during login: {ex.Message}", MsgBoxStyle.Critical)
            ' Log the exception for further investigation if needed.
            Console.WriteLine(ex.ToString())
        Finally
            ' Close the DataReader to release resources.
            If dr IsNot Nothing AndAlso Not dr.IsClosed Then
                dr.Close()
            End If
        End Try
    End Sub




    Public Sub RecordLogin(username As String)
        RecordActivity(username, "Login")
    End Sub

    Public Sub RecordLogout(username As String)
        RecordActivity(username, "Logout")
    End Sub

    Private Sub RecordActivity(username As String, actionType As String)
        Try
            Dim currentTime As DateTime = DateTime.Now
            Dim currentTimeString As String = currentTime.ToString("yyyy-MM-dd HH:mm:ss")

            If actionType = "Login" Then
                ' Insert a new row for login
                Dim insertSql As String = "INSERT INTO tblActivity (Username, TimeIn, TimeOut) VALUES (?, ?, NULL)"
                Using insertCmd As New OleDbCommand(insertSql, cn)
                    insertCmd.Parameters.AddWithValue("@p1", username)
                    insertCmd.Parameters.AddWithValue("@p2", currentTimeString)
                    insertCmd.ExecuteNonQuery()
                End Using
            ElseIf actionType = "Logout" Then
                ' Update the TimeOut column for the latest entry with NULL TimeOut
                Dim updateSql As String = "UPDATE tblActivity SET TimeOut = ? WHERE Username = ? AND TimeOut IS NULL"
                Using updateCmd As New OleDbCommand(updateSql, cn)
                    updateCmd.Parameters.AddWithValue("@p1", currentTimeString)
                    updateCmd.Parameters.AddWithValue("@p2", username)
                    updateCmd.ExecuteNonQuery()
                End Using
            End If
        Catch ex As Exception
            MsgBox($"An error occurred while recording activity: {ex.Message}", MsgBoxStyle.Critical)
        End Try
    End Sub


    Private Function GetUserRole(username As String, password As String) As String
        Dim result As String = "Unknown"


        sql = "SELECT Role FROM tblUsers WHERE Username = @Username AND Password = @Password"
        Using cmd As New OleDbCommand(sql, cn)
            cmd.Parameters.AddWithValue("@Username", username)
            cmd.Parameters.AddWithValue("@Password", password)
            Dim roleResult As Object = cmd.ExecuteScalar()

            If roleResult IsNot Nothing Then
                result = roleResult.ToString()
            End If
        End Using

        Return result
    End Function
    Private Function CheckAccountExists(username As String, password As String) As Boolean
        Dim userExists As Boolean = False

        ' Use StrComp for case-insensitive comparison
        Dim sql As String = "SELECT COUNT(*) FROM tblUsers WHERE StrComp(Username, @Username, 0) = 0 AND StrComp(Password, @Password, 0) = 0"
        Using cmd As New OleDbCommand(sql, cn)
            cmd.Parameters.AddWithValue("@Username", username)
            cmd.Parameters.AddWithValue("@Password", password)
            Dim count As Integer = CInt(cmd.ExecuteScalar())
            If count > 0 Then
                userExists = True
            End If
        End Using

        Return userExists
    End Function
    Private Sub DisabledAccount(username As String)
        ' Disable the user account
        Dim disableSql As String = "UPDATE tblUsers SET Status = 'Disabled' WHERE StrComp(Username, @Username, 0) = 0"
        Using cmd As New OleDbCommand(disableSql, cn)
            cmd.Parameters.AddWithValue("@Username", username)
            cmd.ExecuteNonQuery()
        End Using

        MsgBox("Your account is disabled due to multiple unsuccessful login attempts. Please contact support.", MsgBoxStyle.Critical)
    End Sub

    Private Function GetUserStatus(username As String, password As String) As String
        Dim status As String = "Unknown"

        ' Use StrComp for case-insensitive comparison
        Dim sql As String = "SELECT Status FROM tblUsers WHERE StrComp(Username, @Username, 0) = 0 AND StrComp(Password, @Password, 0) = 0"
        Using cmd As New OleDbCommand(sql, cn)
            cmd.Parameters.AddWithValue("@Username", username)
            cmd.Parameters.AddWithValue("@Password", password)
            Dim statusResult As Object = cmd.ExecuteScalar()

            If statusResult IsNot Nothing Then
                status = statusResult.ToString()
            End If
        End Using

        Return status
    End Function

    Private Sub LinkLabel1_LinkClicked_1(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        frmChangePassword.ShowDialog()
    End Sub
End Class
